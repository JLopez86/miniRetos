//: Playground - noun: a place where people can play

import UIKit

/*
 Generar una serie de números del cero al cien
 Cada vez que imprima un número
 -> Imprimir de acuerdo a la siguientes reglas
 Si el número es divisible entre 5 - imprimir el numero y Bingo
 Si el número es para imprimir el número y la palabra par
 Si el nùmero es impar imprimir el número y la palabra impar
 Si el número se encuentra en un rango de 30 a 40 imprimir número y Viva Swift
  
*/


for num in 0...100{
    
    switch num {
        // Regla cuatro - En rango de 30 a 40 - Viva Swift
    case 30...40:
        print("\(num) #Viva Swift")
    default:
        // Regla uno - Divisible entre 5 - Bingo
        if (num % 5) == 0 {
            print("\(num) #Bingo")
        // Regla dos - pares
        } else if (num % 2) == 0 {
            print("\(num) #Par")
        // Regla tres - impares
        } else if (num % 2) != 0 {
            print("\(num) #Impar")
        }
    }
}