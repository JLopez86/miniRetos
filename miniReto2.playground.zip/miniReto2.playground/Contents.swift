//Mini Reto 2
import UIKit

enum Velocidades : Int {
    case Apagado = 0,
    VelocidadBaja = 20,
    VelocidadMedia = 50,
    VelocidadAlta = 120
    
    init(velocidadInicial: Velocidades){
        self = velocidadInicial
    }
}

class Auto {
    var velocidad = Velocidades.Apagado
    var sube : Bool = true
    init(){
        self.velocidad = .Apagado
    }
    

    
    
    func cambioDeVelocidad() -> (actual: Int, velocidadEnCadena: String){
        
        if velocidad.rawValue == Velocidades.Apagado.rawValue && sube == true {
            print("\(velocidad.rawValue), \(velocidad)")
            velocidad = Velocidades.VelocidadBaja
        } else if velocidad.rawValue == Velocidades.VelocidadBaja.rawValue && sube == true{
            print("\(velocidad.rawValue), \(velocidad)")
            velocidad = Velocidades.VelocidadMedia
        } else if velocidad.rawValue == Velocidades.VelocidadMedia.rawValue && sube == true{
            print("\(velocidad.rawValue), \(velocidad)")
            velocidad = Velocidades.VelocidadAlta
        } else if velocidad.rawValue == Velocidades.VelocidadAlta.rawValue && sube == true{
            print("\(velocidad.rawValue), \(velocidad)")
            velocidad = Velocidades.VelocidadMedia
            sube = false
        } else if velocidad.rawValue == Velocidades.VelocidadMedia.rawValue && sube == false{
            print("\(velocidad.rawValue), \(velocidad)")
            velocidad = Velocidades.VelocidadBaja
        } else if velocidad.rawValue == Velocidades.VelocidadBaja.rawValue && sube == false{
            print("\(velocidad.rawValue), \(velocidad)")
            velocidad = Velocidades.Apagado
            sube = true


        }
        

        
        
        
        return (actual: velocidad.rawValue, String(describing: velocidad))
    }
    
    
}

var rojo = Auto()

for num in 1...20 {
    rojo.cambioDeVelocidad()
}

